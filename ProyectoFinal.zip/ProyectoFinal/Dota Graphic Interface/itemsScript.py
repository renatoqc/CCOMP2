import os
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
from PIL import Image
from io import BytesIO
import requests


def download_image(image_url, image_name, folder):
    try:
        # Extract image name from URL
        a = image_name.split(" ")
        if (a[-1][0] == '(' and a[-1][-1] == ')'): a.pop()
        image_name  = ' '.join(a)
        # Construct the local path to save the image
        local_path = os.path.join(folder, image_name + ".png")

        # Make a request to the image URL
        response = requests.get(image_url, stream=True)
        
        # Check if the request was successful (status code 200)
        if response.status_code == 200:
            # Save the image to the specified folder
            with open(local_path, 'wb') as file:
                for chunk in response.iter_content(chunk_size=128):
                    file.write(chunk)
            print(f"Downloaded: {local_path}")
        else:
            print(f"Failed to download: {image_url}")

    except Exception as e:
        print(f"Error downloading image: {e}")


# Function to extract image links from HTML
def extract_image_links(html_content, base_url):
    soup = BeautifulSoup(html_content, 'html.parser')
    image_links = set()

    # Filter images by class "lazyloaded"
    for img_tag in soup.find_all('img', {'class': 'lazyloaded'}, src=True):
        print("Image Tag ALT: ", img_tag['alt'])
        print("Image Tag data-src: ", img_tag['data-src'])

        img_src = urljoin(base_url, img_tag['data-src'])
        image_links.add((img_src, img_tag['alt']))

    return image_links

# Main function
def main():
    file_path = "Items - Dota 2 Wiki.html"
    
    with open(file_path, "r", encoding="utf-8") as file:
        html_content = file.read()
    
    base_url = "base_url_placeholder"
    
    image_links = extract_image_links(html_content, base_url)

    # Example usage:
    # image_url = "https://static.wikia.nocookie.net/dota2_gamepedia/images/6/6b/Void_Stone_icon.png/revision/latest/scale-to-width-down/60?cb=20160530174037"
    download_folder = "images/itemsImages"

    # Ensure the download folder exists
    os.makedirs(download_folder, exist_ok=True)

    for image_link in image_links:
        download_image(image_link[0], image_link[1], download_folder)

if __name__ == "__main__":
    main()




# Call the function
# download_image(image_url, download_folder)