from bs4 import BeautifulSoup
import requests
import os

# Replace with the actual HTML content or the URL of the HTML page
with open('Dota 2 Heroes.html', 'r', encoding='utf-8') as file:
    html_content = file.read()

# Parse the HTML content
soup = BeautifulSoup(html_content, 'html.parser')

# Find all <a> tags with the specified class
hero_links = soup.find_all('a', class_='herogridpage_HeroIcon_7szOn')

# Extract and print the image URLs
image_urls = []

# Create a directory to save the images
os.makedirs('downloaded_images', exist_ok=True)

for link in hero_links:
    # Extract the style attribute value
    style = link.get('style')

    # Extract the URL from the style attribute
    if style:
        url_start = style.find('"') + 1
        url_end = style.rfind('"')
        image_url = style[url_start:url_end]
        image_urls.append(image_url)


    # Extract the image URL
    image_url = link['style'].split('"')[1]

    # Create a filename based on the last part of the URL
    filename = os.path.join('downloaded_images', os.path.basename(image_url))

    # Download the image
    image_data = requests.get(image_urls[len(image_urls)-1]).content

    # Save the image
    with open(filename, 'wb') as f:
        f.write(image_data)

    print(f"Downloaded: {filename}")
