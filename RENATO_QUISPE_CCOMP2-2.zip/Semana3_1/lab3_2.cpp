#include <iostream>
using namespace std;

// Funci�n para verificar si un n�mero es perfecto
bool esNumeroPerfecto(int num) {
    int sumaDivisores = 1; // Inicializamos la suma con 1 (debido a que todo n�mero es divisible por 1)

    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0) {
            sumaDivisores += i;
            if (i != num / i) {
                sumaDivisores += num / i;
            }
        }
    }

    return sumaDivisores == num;
}

int main() {
    int n;
    cout << "Ingrese la cantidad de n�meros perfectos que desea encontrar: ";
    cin >> n;

    cout << "Los primeros " << n << " n�meros perfectos son:" << std::endl;

    int numero = 2; // Empezamos desde el primer n�mero par
    int encontrados = 0;

    while (encontrados < n) {
        if (esNumeroPerfecto(numero)) {
            cout << numero << " ";
            encontrados++;
        }
        numero++;
    }

    cout << std::endl;

    return 0;
}