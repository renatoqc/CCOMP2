#include <iostream>

int main() {
    int n;
    std::cout << "Ingrese un número n: ";
    std::cin >> n;

    if (n <= 0) {
        std::cout << "Por favor, ingrese un número positivo." << std::endl;
        return 1;
    }

    std::cout << "Los primeros " << n << " números primos son:" << std::endl;

    int num = 2; // Empezamos con el primer número primo (2)
    int encontrados = 0;

    while (encontrados < n) {
        bool esPrimo = true;
        for (int i = 2; i * i <= num; i++) {
            if (num % i == 0) {
                esPrimo = false;
                break;
            }
        }
        if (esPrimo) {
            std::cout << num << " ";
            encontrados++;
        }
        num++;
    }

    std::cout << std::endl;

    return 0;
}